let bars = document.querySelectorAll('.bars .fa-bars');
let menu = document.querySelectorAll('.menu');

bars.forEach(bar =>{
    bar.addEventListener('click', () => {
        menu.forEach(menuItm =>{
            menuItm.classList.toggle('show');
        });
    });
});

let cartIcon = document.querySelectorAll('.cart_menu .fa-cart-shopping');
let cartMenu = document.querySelectorAll('.cart_container');
let closeCart = document.querySelectorAll('.close_cart');

cartIcon.forEach(cart =>{
    cart.addEventListener('click', () =>{
        cartMenu.forEach(cartItem =>{
            cartItem.classList.toggle('show_cart_menu')
        });
    });
});
closeCart.forEach(cartClose =>{
    cartClose.addEventListener('click', () =>{
        cartMenu.forEach(cartItem =>{
            cartItem.classList.remove('show_cart_menu')
        });
    });
});

// AI CHAT BOT
function toggleChat() {
    const chatWindow = document.getElementById('chatbot-window');
    chatWindow.style.display = chatWindow.style.display === 'none' ? 'block' : 'none';
}

function sendMessage() {
    const userInput = document.getElementById('user-input');
    const chatOutput = document.getElementById('chat-output');
    const message = userInput.value.trim();

    if (message) {
        // Display user message
        chatOutput.innerHTML += `<p><strong>You:</strong> ${message}</p>`;
        userInput.value = '';

        // Simulate AI response after a short delay
        setTimeout(() => {
            const aiResponse = getAIResponse(message);
            chatOutput.innerHTML += `<p><strong>AI Assistant:</strong> ${aiResponse}</p>`;
            chatOutput.scrollTop = chatOutput.scrollHeight;
        }, 1000);
    }
}

function getAIResponse(message) {
    // Simple responses for demonstration
    if (message.toLowerCase().includes("clothing")) {
        return "We have a wide range of clothing options. Let me know if you're looking for something specific!";
    } else if (message.toLowerCase().includes("help")) {
        return "I'm here to assist you! Please let me know what you need help with.";
    } else {
        return "I'm not sure about that. Could you please clarify your question?";
    }
}

// ABOUT FILE SLIDER

var swiper = new Swiper('.swiper' , {
    slidesPerView: 5,
    spaceBetween: 30,
    autoplay:{
        delay: 2000,
    },
    loop:true,
});
// SHOP FILE MIXITUP CODE
var mixer = mixitup('.shop_products')

let shopBars = document.querySelector('.shop-bars .fa-list');
let shopMenu = document.querySelector('.shop_menu_category');
let shopMenuLink = document.querySelector('.shop_menu_link');

shopMenuLink.forEach((MenuLink) =>{
    MenuLink.addEventListener('click' , () =>{
        shopMenu.classList.toggle('show_shop_menu');
    });
});